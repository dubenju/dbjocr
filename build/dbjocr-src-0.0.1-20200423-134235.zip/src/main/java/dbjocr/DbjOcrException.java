package dbjocr;

public class DbjOcrException extends Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -400561936587966760L;

    public DbjOcrException(String message) {
        super(message);
    }


}
